var scales = { "Ionien": [0, 2, 4, 5, 7, 9, 11], "Dorien": [0, 2, 3, 5, 7, 9, 10], "Phrygien": [0, 1, 3, 5, 7, 8, 10], "Lydien": [0, 2, 4, 6, 7, 9, 11], "Mixolydien": [0, 2, 4, 5, 7, 9, 10], "\u00c9olien": [0, 2, 3, 5, 7, 8, 10], "Locrien": [0, 1, 3, 5, 6, 8, 10], "Mineure m\u00e9lodique": [0, 2, 3, 5, 7, 9, 11], "Dorien \u266d9": [0, 1, 3, 5, 7, 9, 10], "Lydien augment\u00e9": [0, 2, 4, 6, 8, 9, 11], "Lydien \u266d7": [0, 2, 4, 6, 7, 9, 10], "Mixolydien \u266d13": [0, 2, 4, 5, 7, 8, 10], "Locrien \u266e9": [0, 2, 3, 5, 6, 8, 10], "Alt\u00e9r\u00e9": [0, 1, 3, 4, 6, 8, 10], "Mineure harmonique": [0, 2, 3, 5, 7, 8, 11], "Locrien \u266e13": [0, 1, 3, 5, 6, 9, 10], "Ionien \u266f5": [0, 2, 4, 5, 8, 9, 11], "Dorien \u266f11": [0, 2, 3, 6, 7, 9, 10], "Mixolydien (\u266d9,\u266d13)": [0, 1, 4, 5, 7, 8, 10], "Lydien \u266f9": [0, 3, 4, 6, 7, 9, 11], "Superlocrien \u266d\u266d7": [0, 1, 3, 4, 6, 8, 9], "Ton-Ton": [0, 2, 4, 6, 8, 10], "Pentatonique majeure": [0, 2, 4, 7, 9], "Pentatonique mineure": [0, 3, 5, 7, 10], "Blues majeure": [0, 2, 3, 4, 7, 9], "Blues mineure": [0, 3, 5, 6, 7, 10], "Demi-ton, Ton": [0, 1, 3, 4, 6, 7, 9, 10], "Ton, Demi-ton": [0, 2, 3, 5, 6, 8, 9, 11], "Bebop dominante": [0, 2, 4, 5, 7, 9, 10, 11], "Bebop majeur": [0, 2, 3, 5, 7, 8, 9, 10] }

var chordstype={"M": [0, 4, 7], "(b5)": [0, 4, 6], "11": [0, 4, 5, 7, 10], "11#5": [0, 4, 5, 8, 10], "11b5": [0, 4, 5, 6, 10], "13": [0, 4, 7, 10, 9], "13#5": [0, 4, 8, 9, 10], "13b5": [0, 4, 6, 9, 10], "5": [0, 7], "6": [0, 4, 7, 9], "6b5": [0, 4, 6, 9], "7": [0, 4, 7, 10], "7#5": [0, 4, 8, 10], "7b5": [0, 4, 6, 10], "7sus2": [0, 2, 7, 10], "7sus4": [0, 5, 7, 10], "9": [0, 4, 7, 10, 2], "9#5": [0, 4, 8, 10, 2], "9b5": [0, 4, 6, 10, 2], "9sus2": [0, 2, 7, 10, 2], "9sus4": [0, 5, 7, 10, 2], "aug": [0, 4, 8], "aug6": [0, 4, 8, 9], "dim": [0, 3, 6], "dim(maj11)": [0, 3, 5, 6, 11], "dim(maj13)": [0, 3, 6, 9, 11], "dim(maj7)": [0, 3, 6, 11], "dim(maj9)": [0, 2, 3, 6, 11], "dim11": [0, 3, 5, 6, 10], "dim13": [0, 3, 6, 9, 10], "dim6": [0, 3, 6, 9], "dim7": [0, 3, 6, 9], "dim9": [0, 2, 3, 6, 10], "m": [0, 3, 7], "m#5": [0, 3, 8], "m(maj11)": [0, 3, 5, 7, 11], "m(maj11)#5": [0, 3, 5, 8, 11], "m(maj13)": [0, 3, 7, 9, 11], "m(maj13)#5": [0, 3, 8, 9, 11], "m(maj7)": [0, 3, 7, 11], "m(maj7)#5": [0, 3, 8, 11], "m(maj9)": [0, 2, 3, 7, 11], "m(maj9)#5": [0, 2, 3, 8, 11], "m11": [0, 3, 7, 10, 5], "m11#5": [0, 3, 5, 8, 10], "m13": [0, 3, 7, 10, 9], "m13#5": [0, 3, 8, 9, 10], "m6": [0, 3, 7, 9], "m6#5": [0, 3, 8, 9], "m7": [0, 3, 7, 10], "m7#5": [0, 3, 8, 10], "m7b5": [0, 3, 6, 10], "m9": [0, 3, 7, 10, 2], "m9#5": [0, 2, 3, 8, 10], "maj11": [0, 4, 5, 7, 11], "maj11#5": [0, 4, 5, 8, 11], "maj11b5": [0, 4, 5, 6, 11], "maj13": [0, 4, 7, 11, 9], "maj13#5": [0, 4, 8, 9, 11], "maj13b5": [0, 4, 6, 9, 11], "maj7": [0, 4, 7, 11], "maj7#5": [0, 4, 8, 11], "maj7b5": [0, 4, 6, 11], "maj9": [0, 4, 7, 11, 2], "maj9#5": [0, 2, 4, 8, 11], "maj9b5": [0, 2, 4, 6, 11], "sus2": [0, 2, 7], "sus2(#5)": [0, 2, 8], "sus2(b5)": [0, 2, 6], "sus4": [0, 5, 7], "sus4(#5)": [0, 5, 8], "sus4(b5)": [0, 5, 6]}

var tuningsDict = { "4-string": { "CGCE": { "tuning_array": ["C", "G", "C", "E"], "name": "Cigar Box Open C", "videos": "60 " }, "GDGB": { "tuning_array": ["G", "D", "G", "B"], "name": "Cigar Box Open G", "videos": "81 " }, "GCEA": { "tuning_array": ["G", "C", "E", "A"], "name": "Ukulele GCEA C6", "videos": "101 " }, "GDAE": { "tuning_array": ["G", "D", "A", "E"], "name": "Violin Standard", "videos": "88 " } }, "5-string": {}, "6-string": { "EADGCD": { "tuning_array": ["E", "A", "D", "G", "C", "D"], "name": "", "videos": "19 " }, "DADABD": { "tuning_array": ["D", "A", "D", "A", "B", "D"], "name": "2 Chord - Sleeping With Sirens DADABD", "videos": "77 " }, "CFCGBE": { "tuning_array": ["C", "F", "C", "G", "B", "E"], "name": "4th of July", "videos": "18 " }, "BEDGBE": { "tuning_array": ["B", "E", "D", "G", "B", "E"], "name": "gadfgd", "videos": "25 " }, "ADGBEA": { "tuning_array": ["A", "D", "G", "B", "E", "A"], "name": "A standerd", "videos": "55 " }, "AEAEAE": { "tuning_array": ["A", "E", "A", "E", "A", "E"], "name": "A Modal", "videos": "29 " }, "AADDAA": { "tuning_array": ["A", "A", "D", "D", "A", "A"], "name": "AADDAA", "videos": "149 " }, "CGDGBC": { "tuning_array": ["C", "G", "D", "G", "B", "C"], "name": "Admiral", "videos": "48 " }, "DADAAE": { "tuning_array": ["D", "A", "D", "A", "A", "E"], "name": "AEN STANDARD", "videos": "91 " }, "CCDGAD": { "tuning_array": ["C", "C", "D", "G", "A", "D"], "name": "Aerial Boundaries", "videos": "18 " }, "EADGCF": { "tuning_array": ["E", "A", "D", "G", "C", "F"], "name": "All Fourths", "videos": "43 " }, "ABCDEF": { "tuning_array": ["A", "B", "C", "D", "E", "F"], "name": "Alphabetical Order", "videos": "52 " }, "FACEGB": { "tuning_array": ["F", "A", "C", "E", "G", "B"], "name": "Alternating Thirds", "videos": "250 " }, "ECDGAD": { "tuning_array": ["E", "C", "D", "G", "A", "D"], "name": "andy mckee", "videos": "124 " }, "EADGAE": { "tuning_array": ["E", "A", "D", "G", "A", "E"], "name": "Asus4/7", "videos": "135 " }, "BADDAD": { "tuning_array": ["B", "A", "D", "D", "A", "D"], "name": "bad dad", "videos": "23 " }, "BADABE": { "tuning_array": ["B", "A", "D", "A", "B", "E"], "name": "badabe", "videos": "64 " }, "BAEBAE": { "tuning_array": ["B", "A", "E", "B", "A", "E"], "name": "BAEBAE", "videos": "46 " }, "BAGDAD": { "tuning_array": ["B", "A", "G", "D", "A", "D"], "name": "User Submitted", "videos": "234 " }, "BEAEAC": { "tuning_array": ["B", "E", "A", "E", "A", "C"], "name": "Baritone Alternate", "videos": "116 " }, "AEADEA": { "tuning_array": ["A", "E", "A", "D", "E", "A"], "name": "Baritone DADGAD", "videos": "30 " }, "CFCGGC": { "tuning_array": ["C", "F", "C", "G", "G", "C"], "name": "ben howard ", "videos": "23 " }, "CGCGGC": { "tuning_array": ["C", "G", "C", "G", "G", "C"], "name": "Ben Howard", "videos": "35 " }, "CGCGFC": { "tuning_array": ["C", "G", "C", "G", "F", "C"], "name": "Ben Howard - Esmerelda", "videos": "21 " }, "CFCGFC": { "tuning_array": ["C", "F", "C", "G", "F", "C"], "name": "Ben Howard Promise", "videos": "33 " }, "AAAAAA": { "tuning_array": ["A", "A", "A", "A", "A", "A"], "name": "benjamin taylor", "videos": "95 " }, "BGDGAD": { "tuning_array": ["B", "G", "D", "G", "A", "D"], "name": "BGDGAD", "videos": "48 " }, "CFCFAF": { "tuning_array": ["C", "F", "C", "F", "A", "F"], "name": "Bron-y-aur Stomp", "videos": "19 " }, "D#GCFA#D": { "tuning_array": ["D#", "G", "C", "F", "A#", "D"], "name": "Brown Eyes", "videos": "22 " }, "CGCGGE": { "tuning_array": ["C", "G", "C", "G", "G", "E"], "name": "Burden In My Hand", "videos": "25 " }, "CGDGCD": { "tuning_array": ["C", "G", "D", "G", "C", "D"], "name": "C G D G C D", "videos": "63 " }, "CGCGCD": { "tuning_array": ["C", "G", "C", "G", "C", "D"], "name": "C Modal", "videos": "78 " }, "CGCGGD": { "tuning_array": ["C", "G", "C", "G", "G", "D"], "name": "C sus 2", "videos": "28 " }, "CCEBGD": { "tuning_array": ["C", "C", "E", "B", "G", "D"], "name": "ccebgd", "videos": "16 " }, "CEBEBE": { "tuning_array": ["C", "E", "B", "E", "B", "E"], "name": "Phoenix Rising", "videos": "121 " }, "CFCCGD": { "tuning_array": ["C", "F", "C", "C", "G", "D"], "name": "CFCCGD", "videos": "84 " }, "CFCFGC": { "tuning_array": ["C", "F", "C", "F", "G", "C"], "name": "cfcfgc", "videos": "53 " }, "CFCGCE": { "tuning_array": ["C", "F", "C", "G", "C", "E"], "name": "cfcgce", "videos": "22 " }, "CGCDGE": { "tuning_array": ["C", "G", "C", "D", "G", "E"], "name": "CGCDGE", "videos": "17 " }, "CGCFGE": { "tuning_array": ["C", "G", "C", "F", "G", "E"], "name": "cgcfge", "videos": "25 " }, "CGCGAD": { "tuning_array": ["C", "G", "C", "G", "A", "D"], "name": "CGCGAD", "videos": "31 " }, "CGCGBD": { "tuning_array": ["C", "G", "C", "G", "B", "D"], "name": "CGCGBD", "videos": "53 " }, "CGDEAD": { "tuning_array": ["C", "G", "D", "E", "A", "D"], "name": "CGDEAD", "videos": "18 " }, "CGDFCE": { "tuning_array": ["C", "G", "D", "F", "C", "E"], "name": "cgdfce", "videos": "23 " }, "CGDGCE": { "tuning_array": ["C", "G", "D", "G", "C", "E"], "name": "CGDGCE", "videos": "37 " }, "CGCGCG": { "tuning_array": ["C", "G", "C", "G", "C", "G"], "name": "Cittern 2", "videos": "16 " }, "CACGBC": { "tuning_array": ["C", "A", "C", "G", "B", "C"], "name": "Coldplay", "videos": "20 " }, "DGCFCC": { "tuning_array": ["D", "G", "C", "F", "C", "C"], "name": "Colin Hay 1", "videos": "23 " }, "CEGACE": { "tuning_array": ["C", "E", "G", "A", "C", "E"], "name": "Common C6", "videos": "90 " }, "DADDAD": { "tuning_array": ["D", "A", "D", "D", "A", "D"], "name": "D (Modal)", "videos": "32 " }, "DADFAD": { "tuning_array": ["D", "A", "D", "F", "A", "D"], "name": "D Minor", "videos": "39 " }, "FACECD": { "tuning_array": ["F", "A", "C", "E", "C", "D"], "name": "D minor 9?", "videos": "226 " }, "DADGAC": { "tuning_array": ["D", "A", "D", "G", "A", "C"], "name": "D7sus4", "videos": "70 " }, "DABDAB": { "tuning_array": ["D", "A", "B", "D", "A", "B"], "name": "DABDAB", "videos": "116 " }, "DABEAB": { "tuning_array": ["D", "A", "B", "E", "A", "B"], "name": "DABEAB", "videos": "55 " }, "DABEAD": { "tuning_array": ["D", "A", "B", "E", "A", "D"], "name": "dabead", "videos": "161 " }, "DADADA": { "tuning_array": ["D", "A", "D", "A", "D", "A"], "name": "dada tuning", "videos": "24 " }, "DADADE": { "tuning_array": ["D", "A", "D", "A", "D", "E"], "name": "DADADE", "videos": "102 " }, "DADDAE": { "tuning_array": ["D", "A", "D", "D", "A", "E"], "name": "DADDAE", "videos": "91 " }, "DADEBA": { "tuning_array": ["D", "A", "D", "E", "B", "A"], "name": "DADEBA Billy Mclaughlin Tuning", "videos": "17 " }, "DADFBE": { "tuning_array": ["D", "A", "D", "F", "B", "E"], "name": "DADFBE (Pavement)", "videos": "38 " }, "DADGED": { "tuning_array": ["D", "A", "D", "G", "E", "D"], "name": "dadged", "videos": "20 " }, "DAEAAE": { "tuning_array": ["D", "A", "E", "A", "A", "E"], "name": "DAEAAE - Owl City", "videos": "25 " }, "DAEADE": { "tuning_array": ["D", "A", "E", "A", "D", "E"], "name": "daeade", "videos": "27 " }, "DAEDAD": { "tuning_array": ["D", "A", "E", "D", "A", "D"], "name": "DAEDAD", "videos": "32 " }, "DAFGCE": { "tuning_array": ["D", "A", "F", "G", "C", "E"], "name": "DAFGCE", "videos": "23 " }, "CGDGAD": { "tuning_array": ["C", "G", "D", "G", "A", "D"], "name": "Dave Evans/Kaki King", "videos": "43 " }, "EBDGAD": { "tuning_array": ["E", "B", "D", "G", "A", "D"], "name": "David Crosby", "videos": "58 " }, "EAEEBE": { "tuning_array": ["E", "A", "E", "E", "B", "E"], "name": "David Crowder", "videos": "40 " }, "DBDGBE": { "tuning_array": ["D", "B", "D", "G", "B", "E"], "name": "DBDGBE", "videos": "20 " }, "DDADAD": { "tuning_array": ["D", "D", "A", "D", "A", "D"], "name": "DDADAD", "videos": "68 " }, "DEADAF": { "tuning_array": ["D", "E", "A", "D", "A", "F"], "name": "deadaf (dead as f*ck)", "videos": "33 " }, "DECADE": { "tuning_array": ["D", "E", "C", "A", "D", "E"], "name": "decade tuning", "videos": "42 " }, "DGCGCD": { "tuning_array": ["D", "G", "C", "G", "C", "D"], "name": "DGCGCD", "videos": "38 " }, "DGDDAD": { "tuning_array": ["D", "G", "D", "D", "A", "D"], "name": "DGDDAD-tuning", "videos": "29 " }, "DGDGBE": { "tuning_array": ["D", "G", "D", "G", "B", "E"], "name": "G6. Drop DG", "videos": "45 " }, "GBDGBD": { "tuning_array": ["G", "B", "D", "G", "B", "D"], "name": "Dobro", "videos": "101 " }, "FACFCF": { "tuning_array": ["F", "A", "C", "F", "C", "F"], "name": "Don Ross thing", "videos": "61 " }, "EACEAC": { "tuning_array": ["E", "A", "C", "E", "A", "C"], "name": "double am", "videos": "20 " }, "DADGBD": { "tuning_array": ["D", "A", "D", "G", "B", "D"], "name": "Double Drop D", "videos": "50 " }, "DDDDAD": { "tuning_array": ["D", "D", "D", "D", "A", "D"], "name": "Double unison D", "videos": "57 " }, "BBBBBB": { "tuning_array": ["B", "B", "B", "B", "B", "B"], "name": "Drone B", "videos": "37 " }, "AEADGB": { "tuning_array": ["A", "E", "A", "D", "G", "B"], "name": "Drop A ", "videos": "41 " }, "CGCEGD": { "tuning_array": ["C", "G", "C", "E", "G", "D"], "name": "Drop C (Alternate) ", "videos": "31 " }, "DADGBE": { "tuning_array": ["D", "A", "D", "G", "B", "E"], "name": "Drop D", "videos": "42 " }, "EBGDAD": { "tuning_array": ["E", "B", "G", "D", "A", "D"], "name": "Drop D", "videos": "57 " }, "DADGCE": { "tuning_array": ["D", "A", "D", "G", "C", "E"], "name": "Drop D 7th", "videos": "65 " }, "EADGBC": { "tuning_array": ["E", "A", "D", "G", "B", "C"], "name": "Drop Top C", "videos": "45 " }, "AEADGC": { "tuning_array": ["A", "E", "A", "D", "G", "C"], "name": "Dropped A", "videos": "29 " }, "AADGBE": { "tuning_array": ["A", "A", "D", "G", "B", "E"], "name": "Dropped A", "videos": "79 " }, "CGCFAD": { "tuning_array": ["C", "G", "C", "F", "A", "D"], "name": "Dropped C", "videos": "57 " }, "CGDGBE": { "tuning_array": ["C", "G", "D", "G", "B", "E"], "name": "power chords cheat (dropped daeac#e)", "videos": "63 " }, "DAEGAD": { "tuning_array": ["D", "A", "E", "G", "A", "D"], "name": "Dsus2/sus4", "videos": "69 " }, "EADGAB": { "tuning_array": ["E", "A", "D", "G", "A", "B"], "name": "e cluster", "videos": "62 " }, "EACGAD": { "tuning_array": ["E", "A", "C", "G", "A", "D"], "name": "eacgad", "videos": "21 " }, "EADABE": { "tuning_array": ["E", "A", "D", "A", "B", "E"], "name": "eadabe", "videos": "87 " }, "EBBEBE": { "tuning_array": ["E", "B", "B", "E", "B", "E"], "name": "EBBEBE Tuning", "videos": "24 " }, "EBEGAD": { "tuning_array": ["E", "B", "E", "G", "A", "D"], "name": "EBEGAD", "videos": "17 " }, "EEEEBE": { "tuning_array": ["E", "E", "E", "E", "B", "E"], "name": "EEEEBE", "videos": "35 " }, "EGDGBE": { "tuning_array": ["E", "G", "D", "G", "B", "E"], "name": "EGDGBE tuning", "videos": "52 " }, "EGDGED": { "tuning_array": ["E", "G", "D", "G", "E", "D"], "name": "EGDGED", "videos": "234 " }, "FFFFFF": { "tuning_array": ["F", "F", "F", "F", "F", "F"], "name": "f", "videos": "153 " }, "FACFAC": { "tuning_array": ["F", "A", "C", "F", "A", "C"], "name": "FACFAC", "videos": "59 " }, "FACFAF": { "tuning_array": ["F", "A", "C", "F", "A", "F"], "name": "facfaf", "videos": "18 " }, "FACGAE": { "tuning_array": ["F", "A", "C", "G", "A", "E"], "name": "FACGAE", "videos": "24 " }, "FADFAD": { "tuning_array": ["F", "A", "D", "F", "A", "D"], "name": "fadfad", "videos": "38 " }, "FADGCE": { "tuning_array": ["F", "A", "D", "G", "C", "E"], "name": "fadgce", "videos": "61 " }, "FAFAFA": { "tuning_array": ["F", "A", "F", "A", "F", "A"], "name": "fafafa - expressway 2", "videos": "96 " }, "FAGDAD": { "tuning_array": ["F", "A", "G", "D", "A", "D"], "name": "FAGDAD", "videos": "38 " }, "FAGFAG": { "tuning_array": ["F", "A", "G", "F", "A", "G"], "name": "User Submitted", "videos": "23 " }, "FCFCCF": { "tuning_array": ["F", "C", "F", "C", "C", "F"], "name": "FCFCCF", "videos": "16 " }, "FFCCCC": { "tuning_array": ["F", "F", "C", "C", "C", "C"], "name": "FFCCCC", "videos": "36 " }, "FFCCCF": { "tuning_array": ["F", "F", "C", "C", "C", "F"], "name": "FFCCCF", "videos": "23 " }, "GGDGGD": { "tuning_array": ["G", "G", "D", "G", "G", "D"], "name": "Nick Drake", "videos": "51 " }, "GADDAD": { "tuning_array": ["G", "A", "D", "D", "A", "D"], "name": "GAGDAD", "videos": "23 " }, "GDGGDG": { "tuning_array": ["G", "D", "G", "G", "D", "G"], "name": "gdg", "videos": "40 " }, "ADGCEA": { "tuning_array": ["A", "D", "G", "C", "E", "A"], "name": "Mini Guitar", "videos": "132 " }, "EADGCE": { "tuning_array": ["E", "A", "D", "G", "C", "E"], "name": "have you forgotten", "videos": "29 " }, "BDDDDD": { "tuning_array": ["B", "D", "D", "D", "D", "D"], "name": "Iris", "videos": "39 " }, "DADGAD": { "tuning_array": ["D", "A", "D", "G", "A", "D"], "name": "Modal D", "videos": "18 " }, "DGDGCD": { "tuning_array": ["D", "G", "D", "G", "C", "D"], "name": "Modal G", "videos": "45 " }, "CGCFAC": { "tuning_array": ["C", "G", "C", "F", "A", "C"], "name": "Neil Young", "videos": "77 " }, "BEBEBE": { "tuning_array": ["B", "E", "B", "E", "B", "E"], "name": "Nick Drake", "videos": "64 " }, "CGCFCE": { "tuning_array": ["C", "G", "C", "F", "C", "E"], "name": "Nick Drake", "videos": "30 " }, "DGDGAD": { "tuning_array": ["D", "G", "D", "G", "A", "D"], "name": "Nick Drake", "videos": "36 " }, "EADGEE": { "tuning_array": ["E", "A", "D", "G", "E", "E"], "name": "no b string", "videos": "71 " }, "DACFAD": { "tuning_array": ["D", "A", "C", "F", "A", "D"], "name": "No idea", "videos": "142 " }, "EEBBBB": { "tuning_array": ["E", "E", "B", "B", "B", "B"], "name": "not sure?", "videos": "40 " }, "EAEACE": { "tuning_array": ["E", "A", "E", "A", "C", "E"], "name": "Open A minor", "videos": "33 " }, "DADGAE": { "tuning_array": ["D", "A", "D", "G", "A", "E"], "name": "Open A sus4", "videos": "28 " }, "DAEACE": { "tuning_array": ["D", "A", "E", "A", "C", "E"], "name": "Open Am + Drop D", "videos": "71 " }, "CGCGCE": { "tuning_array": ["C", "G", "C", "G", "C", "E"], "name": "Open C", "videos": "24 " }, "CGEGCC": { "tuning_array": ["C", "G", "E", "G", "C", "C"], "name": "Open C - US", "videos": "32 " }, "CGCEGC": { "tuning_array": ["C", "G", "C", "E", "G", "C"], "name": "Open C Low", "videos": "48 " }, "CGCGCC": { "tuning_array": ["C", "G", "C", "G", "C", "C"], "name": "Open C5", "videos": "26 " }, "CACGCE": { "tuning_array": ["C", "A", "C", "G", "C", "E"], "name": "Open C6", "videos": "27 " }, "CGCGAE": { "tuning_array": ["C", "G", "C", "G", "A", "E"], "name": "Open C6", "videos": "42 " }, "CGCGBE": { "tuning_array": ["C", "G", "C", "G", "B", "E"], "name": "Open Cmaj7", "videos": "68 " }, "DADFAC": { "tuning_array": ["D", "A", "D", "F", "A", "C"], "name": "Open D minor 7th", "videos": "41 " }, "EBEGBE": { "tuning_array": ["E", "B", "E", "G", "B", "E"], "name": "Open E Minor", "videos": "47 " }, "EBEEBE": { "tuning_array": ["E", "B", "E", "E", "B", "E"], "name": "Open E5", "videos": "41 " }, "CFCFAC": { "tuning_array": ["C", "F", "C", "F", "A", "C"], "name": "Open F", "videos": "39 " }, "DGDGBD": { "tuning_array": ["D", "G", "D", "G", "B", "D"], "name": "open g (the dumb way)", "videos": "45 " }, "GGDGBD": { "tuning_array": ["G", "G", "D", "G", "B", "D"], "name": "Open G 12-string", "videos": "63 " }, "DADFAE": { "tuning_array": ["D", "A", "D", "F", "A", "E"], "name": "Opeth Tuning", "videos": "83 " }, "DDDDDD": { "tuning_array": ["D", "D", "D", "D", "D", "D"], "name": "Ostrich", "videos": "31 " }, "BEADGC": { "tuning_array": ["B", "E", "A", "D", "G", "C"], "name": "Oud", "videos": "49 " }, "CFADGC": { "tuning_array": ["C", "F", "A", "D", "G", "C"], "name": "oud arabic style tuning", "videos": "38 " }, "DADEAD": { "tuning_array": ["D", "A", "D", "E", "A", "D"], "name": "Pelican", "videos": "101 " }, "ACDEGA": { "tuning_array": ["A", "C", "D", "E", "G", "A"], "name": "Pentatonic", "videos": "62 " }, "FADGBE": { "tuning_array": ["F", "A", "D", "G", "B", "E"], "name": "Peter Gergely Stay with me", "videos": "31 " }, "EADEAE": { "tuning_array": ["E", "A", "D", "E", "A", "E"], "name": "Pipe", "videos": "76 " }, "DGBDGB": { "tuning_array": ["D", "G", "B", "D", "G", "B"], "name": "Russian Guitar", "videos": "59 " }, "EGDDBD": { "tuning_array": ["E", "G", "D", "D", "B", "D"], "name": "See You Soon Tune", "videos": "29 " }, "CEGCEG": { "tuning_array": ["C", "E", "G", "C", "E", "G"], "name": "two major chords tuning", "videos": "28 " }, "FACGCE": { "tuning_array": ["F", "A", "C", "G", "C", "E"], "name": "User Submitted", "videos": "73 " }, "GGGAAA": { "tuning_array": ["G", "G", "G", "A", "A", "A"], "name": "User Submitted", "videos": "16 " }, "EBGDGC": { "tuning_array": ["E", "B", "G", "D", "G", "C"], "name": "vincent black lightning", "videos": "29 " }, "CGDAEG": { "tuning_array": ["C", "G", "D", "A", "E", "G"], "name": "Violin 5ths", "videos": "37 " } }, "7-string": { "A#C#G#C#F#A#D#": { "tuning_array": ["A#", "C#", "G#", "C#", "F#", "A#", "D#"], "name": "7 string drop c#", "videos": "" }, "BDADGBE": { "tuning_array": ["B", "D", "A", "D", "G", "B", "E"], "name": "7 string drop d", "videos": "10 " }, "DGBDFAD": { "tuning_array": ["D", "G", "B", "D", "F", "A", "D"], "name": "7 string G9 Lap Steel Low Bass", "videos": "" }, "ADAEAC#E": { "tuning_array": ["A", "D", "A", "E", "A", "C#", "E"], "name": "7 string open a sus 4", "videos": "" }, "BD#BD#F#BD#": { "tuning_array": ["B", "D#", "B", "D#", "F#", "B", "D#"], "name": "7 string open b major", "videos": "2 " }, "BEADGBE": { "tuning_array": ["B", "E", "A", "D", "G", "B", "E"], "name": "7 string standard", "videos": "19 " }, "EBEBF#EB": { "tuning_array": ["E", "B", "E", "B", "F#", "E", "B"], "name": "???", "videos": "" }, "ADGCFAD": { "tuning_array": ["A", "D", "G", "C", "F", "A", "D"], "name": "a standard 7-string", "videos": "10 " }, "A#D#G#C#F#A#D#": { "tuning_array": ["A#", "D#", "G#", "C#", "F#", "A#", "D#"], "name": "a# standard 7-string", "videos": "1 " }, "AEADF#BE": { "tuning_array": ["A", "E", "A", "D", "F#", "B", "E"], "name": "alternate drop a (aeadf#be)", "videos": "1 " }, "CABBAGE": { "tuning_array": ["C", "A", "B", "B", "A", "G", "E"], "name": "cabbage", "videos": "24 " }, "DADF#ACE": { "tuning_array": ["D", "A", "D", "F#", "A", "C", "E"], "name": "d9 for 7-string lap steel", "videos": "1 " }, "F#BF#BF#BD#": { "tuning_array": ["F#", "B", "F#", "B", "F#", "B", "D#"], "name": "deconstruction", "videos": "2 " }, "GCGCGCE": { "tuning_array": ["G", "C", "G", "C", "G", "C", "E"], "name": "devin townsend 7-string", "videos": "7 " }, "AEADGBE": { "tuning_array": ["A", "E", "A", "D", "G", "B", "E"], "name": "drop a 7-string", "videos": "15 " }, "ADADGBE": { "tuning_array": ["A", "D", "A", "D", "G", "B", "E"], "name": "drop a/d variation", "videos": "1 " }, "FCFA#D#GC": { "tuning_array": ["F", "C", "F", "A#", "D#", "G", "C"], "name": "drop f 7-string", "videos": "" }, "F#C#F#BEG#C#": { "tuning_array": ["F#", "C#", "F#", "B", "E", "G#", "C#"], "name": "drop f# 7-string", "videos": "" }, "FA#FA#D#GC": { "tuning_array": ["F", "A#", "F", "A#", "D#", "G", "C"], "name": "drop f/a# 8-string variation", "videos": "1 " }, "GDGCFAD": { "tuning_array": ["G", "D", "G", "C", "F", "A", "D"], "name": "drop g 7-string", "videos": "10 " }, "G#D#G#C#F#A#D#": { "tuning_array": ["G#", "D#", "G#", "C#", "F#", "A#", "D#"], "name": "drop g# 7-string", "videos": "" }, "EBEADF#B": { "tuning_array": ["E", "B", "E", "A", "D", "F#", "B"], "name": "E2B2E3A3D4F4B4", "videos": "" }, "EDC#D#GD#C#": { "tuning_array": ["E", "D", "C#", "D#", "G", "D#", "C#"], "name": "EDC#D#GD#C#", "videos": "4 " }, "GCFA#D#GC": { "tuning_array": ["G", "C", "F", "A#", "D#", "G", "C"], "name": "g standard 7-string", "videos": "" }, "G#C#F#BEG#C#": { "tuning_array": ["G#", "C#", "F#", "B", "E", "G#", "C#"], "name": "g# standard 7-string", "videos": "" }, "GGBDFAD": { "tuning_array": ["G", "G", "B", "D", "F", "A", "D"], "name": "gGBDFAD Allans 7 String G9", "videos": "" }, "A#DGCFAD": { "tuning_array": ["A#", "D", "G", "C", "F", "A", "D"], "name": "my fav tuning", "videos": "1 " }, "EEADGBE": { "tuning_array": ["E", "E", "A", "D", "G", "B", "E"], "name": "octave 7-string", "videos": "" }, "DACDF#AD": { "tuning_array": ["D", "A", "C", "D", "F#", "A", "D"], "name": "open d7", "videos": "" } }, "8-string": { "ADADGADG": { "tuning_array": ["A", "D", "A", "D", "G", "A", "D", "G"], "name": "8 string Celtic based", "videos": "" }, "EBEADGBE": { "tuning_array": ["E", "B", "E", "A", "D", "G", "B", "E"], "name": "8 string drop e", "videos": "20 " }, "GCGCGCEG": { "tuning_array": ["G", "C", "G", "C", "G", "C", "E", "G"], "name": "8 string Open C", "videos": "" }, "F#BEADGBE": { "tuning_array": ["F#", "B", "E", "A", "D", "G", "B", "E"], "name": "8 string standard", "videos": "2 " }, "BF#BEADF#B": { "tuning_array": ["B", "F#", "B", "E", "A", "D", "F#", "B"], "name": "B1F2B2E3A3D4F4B4", "videos": "" }, "EDF#ABDF#E": { "tuning_array": ["E", "D", "F#", "A", "B", "D", "F#", "E"], "name": "D69", "videos": "" }, "AC#EG#BC#EG#": { "tuning_array": ["A", "C#", "E", "G#", "B", "C#", "E", "G#"], "name": "Don Helms outside neck e6 8 string steel", "videos": "" }, "D#A#D#G#C#F#A#D#": { "tuning_array": ["D#", "A#", "D#", "G#", "C#", "F#", "A#", "D#"], "name": "double dropped f standard 8-string", "videos": "3 " }, "EAEADGBE": { "tuning_array": ["E", "A", "E", "A", "D", "G", "B", "E"], "name": "drop e/a 8-string variation", "videos": "1 " }, "FCFA#D#G#CF": { "tuning_array": ["F", "C", "F", "A#", "D#", "G#", "C", "F"], "name": "drop f 8-string", "videos": "2 " }, "FA#D#G#C#F#A#D#": { "tuning_array": ["F", "A#", "D#", "G#", "C#", "F#", "A#", "D#"], "name": "f standard 8-string", "videos": "" }, "FAFACGBE": { "tuning_array": ["F", "A", "F", "A", "C", "G", "B", "E"], "name": "FAFACGBE", "videos": "" }, "DA#D#G#C#F#A#D#": { "tuning_array": ["D", "A#", "D#", "G#", "C#", "F#", "A#", "D#"], "name": "Half Step Single Drop D Tuning", "videos": "" }, "EA#D#G#C#F#A#D#": { "tuning_array": ["E", "A#", "D#", "G#", "C#", "F#", "A#", "D#"], "name": "Half Step Single Drop E Tuning", "videos": "" } }, "9-string": { "GCFEADGBE": { "tuning_array": ["G", "C", "F", "E", "A", "D", "G", "B", "E"], "name": "9 string", "videos": "" }, "DFADAEFCE": { "tuning_array": ["D", "F", "A", "D", "A", "E", "F", "C", "E"], "name": "D minor 9th - 9 string", "videos": "" }, "EABCDEFGA": { "tuning_array": ["E", "A", "B", "C", "D", "E", "F", "G", "A"], "name": "gusli", "videos": "" } }, "10-string": {}, "11-string": {}, "12-string": {} }

var defaultColors={'root' : '#e70000',
    "minorsecond" : "#f9e400",
    "majorsecond" : "#f9a500",
    "minorthird" : "#005e00",
    "majorthird" : "#006c00",
    "perfectfourth" : "#009a00",
    "diminishedfifth" : "#000f41",
    "perfectfifth" : "#004997",
    "minorsixth" : "#a86b62",
    "majorsixth" : "#de516c",
    "minorseventh" : "#782586",
    "majorseventh" : "#781962",
    "uniquecolor" : "#fefefe",
    "textcolor":"#ffffff"}

var requestFlask = {}
requestFlask["notes"] = []
requestFlask["colors"] = {}
requestFlask["textcolor"]='#ffffff'

window.onload = function () {
    choice='scale'

    createTuningSelector(numberString)
    /* Event listener change string note */
    trianglehaut = document.getElementsByClassName("trianglehaut")
    trianglebas = document.getElementsByClassName("trianglebas")

    for (let i = 0; i < trianglehaut.length; i++) {
        trianglehaut[i].addEventListener("click", TuningUp)
    }
    for (let i = 0; i < trianglehaut.length; i++) {
        trianglebas[i].addEventListener("click", TuningDown)
    }


    allnoteleft=document.getElementsByClassName('roundchoice')
    for (let i = 0; i < allnoteleft.length; i++) {
        allnoteleft[i].addEventListener("click", noteSelector)
    }
    createModeSelector() 
    document.getElementById("rootselector").addEventListener("change", modeSelect)
    document.getElementById("modeselector").addEventListener("change", modeSelect)
    document.getElementById("tuningselector").addEventListener("change", changeTuning)
    document.getElementById("textcolor").addEventListener("change",textColor)


    document.getElementById("uniquecolor").addEventListener("change",uniqueColor)

    document.getElementById("generatebutton").addEventListener('click',request)
    /* Event listtener change string note */
    themeChoiceCircle = document.getElementsByClassName("roundtheme")

    for (let i = 0; i < themeChoiceCircle.length; i++) {
        themeChoiceCircle[i].addEventListener("click", themechoice)
    }
    requestFlask["root"]="A"
    requestFlask['intervalChoice']=true
    requestFlask['noteChoice']=false
    document.getElementById('intervals').style.backgroundColor='#06BC06'
    document.getElementById('button').addEventListener('click',toggleButtonLeft)

    colorPickerCircle=document.getElementsByClassName('colorpickercircle')
    for (let i = 0; i < colorPickerCircle.length; i++) {
        colorPickerCircle[i].addEventListener('change',checkAndSaveColors)      
    }
    document.getElementById('restoredefault').addEventListener('click',restoreDefault)


    checkAndSaveColors()
}

function toggleButtonLeft(){
    ToggleButton=document.getElementById('circlebutton')
    if (ToggleButton.style.marginLeft=='auto'){
        ToggleButton.style.marginLeft='0'
        ToggleButton.style.margin='0 3px'
        choice='scale'
        createModeSelector(choice)
        document.getElementById("modeselector").addEventListener("change", modeSelect)
    }
    else{
        ToggleButton.style.marginLeft='auto'
        choice='chord'
        createModeSelector(choice)
        document.getElementById("modeselector").addEventListener("change", modeSelect)
    }
 /*    margin: 0 3px; */
}


/* RAJOUTER EVENT A CHAQUE FOIS */
function createModeSelector(choice){
    if (choice=='scale'){
        modeSelectDiv = document.getElementById('modeselect')
        modeSelectDiv.innerHTML='Mode : '
        selectTag = document.createElement('select')
        selectTag.name = "mode"
        selectTag.id = "modeselector"
        optionSelect = document.createElement('option')
        optionSelect.value="custom"
        optionSelect.innerHTML="Custom"
        selectTag.appendChild(optionSelect)
        
        for (const key of Object.keys(scales)){
         optionSelect = document.createElement('option')
         optionSelect.value=key
         optionSelect.innerHTML=key
         selectTag.appendChild(optionSelect)
        }
        modeSelectDiv.appendChild(selectTag)
    }
    else if(choice=='chord'){
        modeSelectDiv = document.getElementById('modeselect')
        modeSelectDiv.innerHTML='Type : '
        selectTag = document.createElement('select')
        selectTag.name = "type"
        selectTag.id = "modeselector"
        optionSelect = document.createElement('option')
        optionSelect.value="custom"
        optionSelect.innerHTML="Custom"
        selectTag.appendChild(optionSelect)
        
        for (const key of Object.keys(chordstype)){
         optionSelect = document.createElement('option')
         optionSelect.value=key
         optionSelect.innerHTML=key
         selectTag.appendChild(optionSelect)
        }
        modeSelectDiv.appendChild(selectTag)
    }
}

function noteSelector(objet) {

    noteDiv=objet.target
    modeSelectorDiv = document.getElementById('modeselector')
    allOptions =modeSelectorDiv.getElementsByTagName("option")
    for (const i in allOptions) {
        if (allOptions[i].value=='custom'){
            modeSelectorDiv.selectedIndex=i;
            break
        }
    }
    
    if (noteDiv.style.backgroundColor == 'rgb(6, 188, 6)') {
        if (requestFlask["notes"].includes(noteDiv.id)) {
            console.log(requestFlask["notes"].indexOf(noteDiv.id))
            requestFlask["notes"].splice(requestFlask["notes"].indexOf(noteDiv.id), 1)
        }
        else {
        }
        /* if already clicked */
        noteDiv.style.backgroundColor = "white"
    }
    else {
        noteDiv.style.backgroundColor = '#06BC06'
        if (requestFlask["notes"].includes(noteDiv.id)) {
        }
        else {
            requestFlask["notes"].push(noteDiv.id)
        }
    }
    console.log(requestFlask["notes"])
}

var numberString = 6;

function addTuning() {
    if (numberString == 9) { }
    else {
        tuningContainer = document.getElementById('tuningContainer')

        var firstDiv = document.createElement("div")
        firstDiv.className = "d-flex"

        var secondDiv = document.createElement("div")
        secondDiv.className = "roundtuning d-flex align-items-center justify-content-center"

        var firstImg = document.createElement("img")
        firstImg.className = "trianglehaut"
        firstImg.src = "image/icons8-tri-croissant-100.png"
        firstImg.alt = "triangle haut"
        firstImg.addEventListener("click", TuningUp)

        var thirdDiv = document.createElement("div")
        thirdDiv.innerHTML = "E"
        thirdDiv.id = "string" + String(numberString + 1)

        var secondImg = document.createElement("img")
        secondImg.className = "trianglebas"
        secondImg.src = "image/icons8-tri-décroissant-100.png"
        secondImg.alt = "triangle bas"
        secondImg.addEventListener("click", TuningDown)

        secondDiv.appendChild(firstImg)
        secondDiv.appendChild(thirdDiv)
        secondDiv.appendChild(secondImg)

        firstDiv.appendChild(secondDiv)
        tuningContainer.appendChild(firstDiv)

        numberString += 1

        Tuning.push("E")
        requestFlask["tuning"] = Tuning
        createTuningSelector(numberString)
    }
}


function removeTuning() {
    if (numberString == 4) { }
    else {
        tuningContainer = document.getElementById('tuningContainer')
        tuningString = tuningContainer.children
        numberOfString = tuningString.length
        tuningContainer.removeChild(tuningString[numberOfString - 1])
        numberString -= 1
        Tuning.pop()
        requestFlask["tuning"] = Tuning
        createTuningSelector(numberString)
    }

}


function createTuningSelector(numberString) {

    tuningSelector = document.getElementById("tuningselector")
    tuningSelector.innerHTML=''
    tuningDictStrings = tuningsDict[String(numberString) + "-string"]
    optionValue = document.createElement("option")
    optionValue.value = 'custom'
    optionValue.innerHTML = 'Custom'
    tuningSelector.appendChild(optionValue)
    for (const key of Object.keys(tuningDictStrings)) {
        optionValue = document.createElement("option")
        optionValue.value = key
        var stringtune=''
        for (let i = 0; i < tuningDictStrings[key]["tuning_array"].length; i++) {
            if (i==tuningDictStrings[key]["tuning_array"].length-1){
                stringtune += tuningDictStrings[key]["tuning_array"][i]
            }
            else{
                stringtune += tuningDictStrings[key]["tuning_array"][i]+"-"
            }
        }
        optionValue.innerHTML = stringtune
        /*         optionValue.innerHTML = key + "-" + tuningDictStrings[key]["name"] to add name  */
        console.log(tuningDictStrings[key]["name"])
        tuningSelector.appendChild(optionValue)
    }
}


function themechoice(objet){
    if (objet.target.id=='intervals'){
        if (requestFlask['intervalChoice']){}
        else{objet.target.style.backgroundColor='#06BC06';
        document.getElementById('notes').style.backgroundColor='white';
        requestFlask['intervalChoice']=true;
        requestFlask['noteChoice']=false;

    }
    }
    if (objet.target.id=='notes'){
        if (requestFlask['noteChoice']){}
        else{objet.target.style.backgroundColor='#06BC06';
        document.getElementById('intervals').style.backgroundColor='white'};
        requestFlask['intervalChoice']=false;
        requestFlask['noteChoice']=true;
    }
}

function changeTuning() {

    tuningContainer = document.getElementById('tuningContainer').children
    tuningSelectorDiv = document.getElementById("tuningselector")
    console.log(tuningSelectorDiv)
    tuningSelectora = tuningSelectorDiv.options[tuningSelectorDiv.selectedIndex].value
/* FINIR FONCTION APPELER LE TUNING QUON CHANGE  */
    tuningDictStringValue=tuningsDict[String(numberString) + '-string'][tuningSelectora]['tuning_array']
    console.log(tuningDictStringValue)
    requestFlask["tuning"]=tuningDictStringValue

    for (let i = 0; i < requestFlask["tuning"].length; i++) {
        tuningContainer[i].children[0].children[1].innerHTML = requestFlask["tuning"][i]
        console.log(requestFlask["tuning"][i])

    }
}
var Tuning = ["E", "A", "D", "G", "B", "E"]
requestFlask["tuning"] = Tuning

function TuningUp(objet) {
    var allNotes = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]
    var index = allNotes.indexOf(objet.target.parentNode.children[1].innerHTML)
    objet.target.parentNode.children[1].innerHTML = allNotes[(index + 1 + 12) % 12]

    allChildrenOfBigParent = objet.target.parentNode.parentNode.parentNode.children
    targetParent = objet.target.parentNode.parentNode
    index = Array.from(allChildrenOfBigParent).indexOf(targetParent)

    Tuning[index] = String(objet.target.parentNode.children[1].innerHTML)
    console.log(Tuning)
    requestFlask["tuning"] = Tuning
    tuningSelectorTune = document.getElementById('tuningselector')
    allOptions =tuningSelectorTune.getElementsByTagName("option")
    console.log(tuningSelectorTune.getElementsByTagName("option"))
    for (const i in allOptions) {
        if (allOptions[i].value=='custom'){
            tuningSelectorTune.selectedIndex=i;
            break
        }
    }

}

function TuningDown(objet) {
    var allNotes = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]
    var index = allNotes.indexOf(objet.target.parentNode.children[1].innerHTML)
    objet.target.parentNode.children[1].innerHTML = allNotes[(index - 1 + 12) % 12]

    allChildrenOfBigParent = objet.target.parentNode.parentNode.parentNode.children
    targetParent = objet.target.parentNode.parentNode
    index = Array.from(allChildrenOfBigParent).indexOf(targetParent)
    Tuning[index] = String(objet.target.parentNode.children[1].innerHTML)
    console.log(Tuning)
    requestFlask["tuning"] = Tuning
    
    tuningSelectorTune = document.getElementById('tuningselector')
    allOptions =tuningSelectorTune.getElementsByTagName("option")
    console.log(tuningSelectorTune.getElementsByTagName("option"))
    for (const i in allOptions) {
        if (allOptions[i].value=='custom'){
            tuningSelectorTune.selectedIndex=i;
            break
        }
    }

}




function modeSelect() {
    console.log("works")

    var allNotes = ["A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"]

    rootDiv = document.getElementById('rootselector')
    root = rootDiv.options[rootDiv.selectedIndex].value
    requestFlask["root"]=root

    chosenScaleDiv = document.getElementById('modeselector')
    if (choice=='scale'){
    chosenScale = scales[chosenScaleDiv.options[chosenScaleDiv.selectedIndex].value]
    }
    else if(choice=='chord'){
        chosenScale = chordstype[chosenScaleDiv.options[chosenScaleDiv.selectedIndex].value]
    }

    if (chosenScaleDiv.options[chosenScaleDiv.selectedIndex].value == 'Custom') {
    }
    else {
        index = allNotes.indexOf(root)
        tempArray = []
        for (let i = 0; i < chosenScale.length; i++) {
            console.log((index + chosenScale[i]) % 12)
            tempArray.push(allNotes[(index + chosenScale[i]) % 12])
            console.log(tempArray)
        }
        onModeChangeColorNotes(tempArray)
        requestFlask['notes'] = tempArray
    }

}


function onModeChangeColorNotes(scale) {
    allSelectableNotes = document.getElementsByClassName('roundchoice')
    
    for (const i of allSelectableNotes) {
        i.style.backgroundColor = 'white'
        console.log(i.id)
        if (scale.includes(i.id)) {
            i.style.backgroundColor = '#06BC06'
        }
    }

}


function setColorWindow(){
    document.getElementById('themeprincipalepage').style.display ='none'
    document.getElementById('colorpanel').style.display='block'
}

function closeColorWindow(){
    document.getElementById('themeprincipalepage').style.display ='block'
    document.getElementById('colorpanel').style.display='none'
}

function checkAndSaveColors(){
    colorsCircle=document.getElementsByClassName('colorpickercircle')
    for (let i = 0; i < colorsCircle.length; i++) {
        nameInterval=colorsCircle[i].id.split('interval')[1]
        requestFlask['colors'][nameInterval]=colorsCircle[i].value
    }
}
function applyColorWindow(){
    document.getElementById('themeprincipalepage').style.display ='block'
    document.getElementById('colorpanel').style.display='none'
    checkAndSaveColors()
}
function textColor(){
    requestFlask["textcolor"]=document.getElementById("textcolor").value
}
function uniqueColor(){
    colorPickerCircleDiv=document.getElementById('container-allcolors').getElementsByClassName('colorpickercircle')
    uniqueColorDivValue=document.getElementById('uniquecolor').value

    for (let i = 0; i < colorPickerCircleDiv.length; i++) {
        colorPickerCircleDiv[i].value=uniqueColorDivValue
    }
}

function restoreDefault(){
    colorPickerCircleDiv=document.getElementById('container-allcolors').getElementsByClassName('colorpickercircle')
    for (let i = 0; i < colorPickerCircleDiv.length; i++) {
        valueOfIDInterval=colorPickerCircleDiv[i].id.split('interval')[1]
        colorPickerCircleDiv[i].value=defaultColors[valueOfIDInterval]
    }

    uniqueColorAndText=document.getElementById('uniquecolorandtext').getElementsByClassName('colorpickercircle')

    for (let i = 0; i < uniqueColorAndText.length; i++) {
        valueOfIDInterval=uniqueColorAndText[i].id
        uniqueColorAndText[i].value=defaultColors[valueOfIDInterval]
        
    }
    checkAndSaveColors()
}

var downloadbool=false
var i=0
function request() {
    console.log(requestFlask)
    const Http = new XMLHttpRequest();
    const url = "http://127.0.0.1:5000/";
    Http.onerror = function(e){
        imgresponse = document.getElementById("imgsvg")
        imgresponse.className='d-flex align-items-center justify-content-center'
        imgresponse.innerHTML=''
        divalert=document.createElement('div')
        divalert.style.color='black'
        divalert.style.fontWeight=600
        divalert.style.fontSize='18px'
        divalert.innerHTML = ' Oups ! La communication avec le serveur est difficile ... '+i
        imgresponse.appendChild(divalert)
        i++
    };
    Http.open("POST", url);
    Http.setRequestHeader("content-type", "application/json")
    Http.send(JSON.stringify(requestFlask));
    console.log(JSON.stringify(requestFlask))
    

    Http.onreadystatechange = function() {
        if(this.status==200 && this.readyState==4){
            imgresponse = document.getElementById("imgsvg")
            imgresponse.innerHTML = Http.responseText
            imgresponse.children[0].src=imgresponse.children[0].src+"?" + new Date().getTime();
    
            downloadlink=document.getElementById('downloadlink')
            downloadlink.href=imgresponse.children[0].src
            downloadlink.download='ScaleDiagram'
            if (!downloadbool){
            downloadbutton=document.createElement('div')
            downloadbutton.id='downloadbutton'
            downloadbutton.innerHTML='Download'
            downloadlink.appendChild(downloadbutton)
            downloadbool=true
        }
            console.log(Http.responseText)
        }
        else{
            imgresponse = document.getElementById("imgsvg")
            imgresponse.innerHtml = ' Oups ! La communication avec le serveur est difficile ... '
        }
    }

    console.log("Requete envoyé")
}






